/**
 * 注意:这个代码是由代码生成器生成的,当前生成器的版本号为: (2.3.1).
 * 如果你对代码生成器生成的代码有任何建议,请联系架构组.
 * 请不要手动编辑这个文件!!!
 */
package com.yilihuo.cloud.demo.api;

import cn.gooday.jsh.service.common.dto.RestControllerResult;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.List;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-03-02T10:33:58.221+08:00")

@Api(value = "tasks", description = "the tasks API")
@RestController
@RequestMapping("/tasks")
public interface TasksApi {

    @ApiOperation(value = "获取定单信息", nickname = "addGood", notes = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "正確操作"),
        @ApiResponse(code = 400, message = "錯誤操作") })
    @RequestMapping(value = "/tasks/add",
        method = RequestMethod.GET)
    RestControllerResult addGood(@ApiParam(value = "",required=true) @PathVariable("goodId") String goodId);


    @ApiOperation(value = "获取定单信息", nickname = "delGood", notes = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "正確操作"),
        @ApiResponse(code = 400, message = "錯誤操作") })
    @RequestMapping(value = "/tasks/del",
        method = RequestMethod.GET)
    RestControllerResult delGood(@ApiParam(value = "",required=true) @PathVariable("goodId") String goodId);


    @ApiOperation(value = "获取定单信息", nickname = "getGood", notes = "", tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "正確操作"),
        @ApiResponse(code = 400, message = "錯誤操作") })
    @RequestMapping(value = "/tasks/{goodId}",
        method = RequestMethod.GET)
    RestControllerResult getGood(@ApiParam(value = "",required=true) @PathVariable("goodId") String goodId);


    @ApiOperation(value = "获取定单信息", nickname = "tasksList", notes = "", response = Object.class, tags={  })
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "正確操作", response = Object.class),
        @ApiResponse(code = 400, message = "錯誤操作") })
    @RequestMapping(value = "/tasks/list",
        method = RequestMethod.GET)
    RestControllerResult tasksList(@ApiParam(value = "获取的数据偏移量") @Valid @RequestParam(value = "offset", required = false) Integer offset,@ApiParam(value = "数据个数") @Valid @RequestParam(value = "limit", required = false) Integer limit);

}
