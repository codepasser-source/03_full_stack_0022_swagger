package com.yilihuo.cloud.demo.api.dto.mst;

import java.util.Objects;

/**
 * 团队dto，放置团队的相关信息.
 *
 * @author 王靖靖
 * @date 27/02/2018 17:59
 */
public class TeamInsertParam {

  // 团队名称
  private String teamName;
  // 团队最大人员数量
  private String maxPersons;

  public String getTeamName() {
    return teamName;
  }

  public void setTeamName(String teamName) {
    this.teamName = teamName;
  }

  public String getMaxPersons() {
    return maxPersons;
  }

  public void setMaxPersons(String maxPersons) {
    this.maxPersons = maxPersons;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TeamInsertParam that = (TeamInsertParam) o;
    return Objects.equals(teamName, that.teamName) && Objects.equals(maxPersons, that.maxPersons);
  }

  @Override
  public int hashCode() {

    return Objects.hash(teamName, maxPersons);
  }

  @Override
  public String toString() {
    final StringBuffer sb = new StringBuffer("TeamInsertParam{");
    sb.append("teamName='").append(teamName).append('\'');
    sb.append(", maxPersons='").append(maxPersons).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
