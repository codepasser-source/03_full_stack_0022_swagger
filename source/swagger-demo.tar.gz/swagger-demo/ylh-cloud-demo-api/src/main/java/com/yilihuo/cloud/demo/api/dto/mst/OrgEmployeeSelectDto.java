package com.yilihuo.cloud.demo.api.dto.mst;

import java.io.Serializable;
import java.util.Objects;

/**
 * 联系人选择dto，用于页面复选框展示.
 *
 * @author 王靖靖
 * @date 25/02/2018 15:26
 */
public class OrgEmployeeSelectDto implements Serializable {
  private int orgId;
  private String orgName;

  public int getOrgId() {
    return orgId;
  }

  public void setOrgId(int orgId) {
    this.orgId = orgId;
  }

  public String getOrgName() {
    return orgName;
  }

  public void setOrgName(String orgName) {
    this.orgName = orgName;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OrgEmployeeSelectDto that = (OrgEmployeeSelectDto) o;
    return orgId == that.orgId && Objects.equals(orgName, that.orgName);
  }

  @Override
  public int hashCode() {

    return Objects.hash(orgId, orgName);
  }

  @Override
  public String toString() {
    final StringBuffer sb = new StringBuffer("OrgEmployeeSelectDto{");
    sb.append("orgId=").append(orgId);
    sb.append(", orgName='").append(orgName).append('\'');
    sb.append('}');
    return sb.toString();
  }
}
