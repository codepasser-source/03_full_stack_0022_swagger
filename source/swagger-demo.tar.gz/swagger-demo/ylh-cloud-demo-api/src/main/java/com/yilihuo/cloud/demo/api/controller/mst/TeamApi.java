package com.yilihuo.cloud.demo.api.controller.mst;

import cn.gooday.jsh.service.common.dto.RestControllerResult;
import com.yilihuo.cloud.demo.api.dto.mst.OrgEmployeeSelectDto;
import com.yilihuo.cloud.demo.api.dto.mst.TeamInsertParam;
import java.util.List;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 团队模块api定义.
 *
 * @author 王靖靖
 * @date 25/02/2018 13:23
 */
@RestController
@RequestMapping("/api/mst/team")
public interface TeamApi {
  /**
   * 获取一个公司的组织结构.
   *
   * @return 统一封装过的组织结构列表
   */
  @RequestMapping(value = "get-teamdto-by-companyid")
  RestControllerResult<List<OrgEmployeeSelectDto>> getTeamDtoByCompanyId(@RequestParam("companyId") Integer companyId);

  /**
   * 演示去除封装的接口.
   *
   * <p>如果API接口的返回值类型不是RestControllerResult，则必须设置AspectCommon.needDecorate为 false.
   *
   * @return 组织结构列表
   */
  @RequestMapping(value = "get-raw-teamdto")
  List<OrgEmployeeSelectDto> getTeamDtoWithoutDecorated();

  /**
   * 创建团队，用来演示feign的客户度调用的.
   *
   * @param team 团队对象
   * @return 插入成功返回true，否则返回false
   */
  @RequestMapping(value = "insert-team", method = RequestMethod.POST)
  RestControllerResult<Boolean> insertTeam(@RequestBody TeamInsertParam team);
}
