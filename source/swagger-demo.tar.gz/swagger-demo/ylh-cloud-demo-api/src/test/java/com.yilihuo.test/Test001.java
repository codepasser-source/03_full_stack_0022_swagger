package com.yilihuo.test;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import org.junit.Test;

/**
 * @author 开发者中文姓名
 * @date 18-3-2 上午9:34
 */
public class Test001 {

  static void loadYaml(File file, List<File> files) {

    if (file.isFile()) {

      if (file.getName().endsWith(".yaml")) files.add(file);

    } else {

      Arrays.asList(Objects.requireNonNull(file.listFiles())).forEach(f -> loadYaml(f, files));
    }
  }

  @Test
  public void test01() {
    File file =
        new File("/home/fzxs/workspace/swagger-demo/ylh-cloud-demo-api/src/main/resources/yaml");
    System.out.println(file);

    List<File> files = new ArrayList<>();
    loadYaml(file, files);
    System.out.println(files);
  }
}
