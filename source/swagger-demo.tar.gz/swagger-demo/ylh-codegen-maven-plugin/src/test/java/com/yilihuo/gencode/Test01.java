package com.yilihuo.gencode;

import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.generator.exception.ApiException;
import io.swagger.generator.model.GeneratorInput;
import io.swagger.generator.online.Generator;
import io.swagger.util.Yaml;
import java.io.IOException;
import org.junit.Ignore;
import org.junit.Test;

/**
 * @author 开发者中文姓名
 * @date 18-2-27 下午2:44
 */
public class Test01 {
  @Test
  @Ignore
  public void test01() throws ApiException, IOException {
    GeneratorInput opts = new GeneratorInput();

    System.out.println(getClass().getResource("/swagger.json"));

    JsonNode json = Yaml.mapper().readTree(getClass().getResourceAsStream("/swagger.yaml"));

    opts.setSpec(json);

    String filename = Generator.generateServer("spring", opts);

    System.out.println(filename);
  }

  @Test
  public void test02() throws IOException {}
}
