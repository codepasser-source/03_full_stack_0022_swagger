package com.yilihuo.swagger;

import io.swagger.codegen.DefaultGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class YlhGenerator extends DefaultGenerator {
  static Logger LOGGER = LoggerFactory.getLogger(YlhGenerator.class);

  //  @Override
  //  public List<File> generate() {
  //    config.apiTemplateFiles().remove("apiController.mustache");
  //  }
  //    return super.generate();
}
